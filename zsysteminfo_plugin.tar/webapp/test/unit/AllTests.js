sap.ui.define([
	"zsysteminfo/zsysteminfoplugin/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
