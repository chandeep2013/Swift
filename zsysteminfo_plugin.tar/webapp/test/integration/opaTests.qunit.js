/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["zsysteminfo/zsysteminfoplugin/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
