sap.ui.define([
    "sap/ui/core/UIComponent",
    "zsysteminfo/zsysteminfoplugin/model/models",
    "sap/ushell/Container",
], (UIComponent, models, Container) => {
    "use strict";

    return UIComponent.extend("zsysteminfo.zsysteminfoplugin.Component", {
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },

        init() {
            UIComponent.prototype.init.apply(this, arguments);

            var oRenderer = sap.ushell.Container.getRenderer("fiori2");
            console.log("oRenderer",oRenderer)
            if (oRenderer) {
                debugger;
                var sSystem = sap.ushell.Container.getLogonSystem().getName();
                var sClient = sap.ushell.Container.getLogonSystem().getClient();
                var sText = sSystem + "-" + sClient;
                oRenderer.addHeaderEndItem({
                    id: "systemInfoText",
                    icon: "sap-icon://sys-monitor",
                    text: sText,
                    tooltip: "System Information",
                    area: "end"
                }, true);
                oRenderer.setHeaderTitle(sText);

            }
        }
    });
});