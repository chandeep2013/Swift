# Implementation Guide - Blulist SAP CAP Application

## Prerequisites

Before starting the implementation, ensure you have the following installed:

### Development Tools
- **Node.js** (v18.x or higher)
- **npm** (v9.x or higher)
- **SAP CAP CLI** (`npm install -g @sap/cds-dk`)
- **Git**
- **VS Code** or **SAP Business Application Studio**

### SAP BTP Account Requirements
- SAP BTP trial or enterprise account
- Cloud Foundry environment enabled
- SAP HANA Cloud instance provisioned
- XSUAA service instance

### Recommended VS Code Extensions
- SAP CDS Language Support
- SAP Fiori Tools
- ESLint
- Prettier

---

## Step 1: Project Initialization

### 1.1 Create New CAP Project

```bash
# Create project directory
cds init blulist-app --add java,hana,samples

cd blulist-app
```

### 1.2 Install Dependencies

```bash
npm install
```

### 1.3 Project Structure Setup

Create the following directory structure:

```
blulist-app/
├── app/
│   ├── requestor/
│   ├── approver/
│   └── admin/
├── db/
│   ├── schema.cds
│   ├── data/
│   └── src/
├── srv/
│   ├── service-definition.cds
│   ├── requestor-service.js
│   ├── approver-service.js
│   ├── admin-service.js
│   └── common-service.js
├── test/
└── package.json
```

---

## Step 2: Database Schema Implementation

### 2.1 Create Schema File

Copy the `db-schema.cds` content to `db/schema.cds`

### 2.2 Create Service Definitions

Copy the `service-definition.cds` content to `srv/service-definition.cds`

### 2.3 Update package.json

Add the following to your `package.json`:

```json
{
  "name": "blulist-app",
  "version": "1.0.0",
  "description": "Project Role Request Management System",
  "repository": "https://github.com/yourorg/blulist-app",
  "license": "ISC",
  "engines": {
    "node": ">=18"
  },
  "dependencies": {
    "@sap/cds": "^7",
    "@sap/xssec": "^3",
    "express": "^4",
    "passport": "^0.6"
  },
  "devDependencies": {
    "@sap/cds-dk": "^7",
    "@sap/eslint-plugin-cds": "^2",
    "eslint": "^8",
    "jest": "^29",
    "sqlite3": "^5"
  },
  "scripts": {
    "start": "cds-serve",
    "watch": "cds watch",
    "test": "jest",
    "build": "cds build",
    "deploy": "cds deploy"
  },
  "cds": {
    "requires": {
      "db": {
        "kind": "sql"
      },
      "auth": {
        "kind": "xsuaa"
      }
    },
    "hana": {
      "deploy-format": "hdbtable"
    }
  }
}
```

---

## Step 3: Service Implementation

### 3.1 Requestor Service Implementation

Create `srv/requestor-service.js`:

```javascript
const cds = require('@sap/cds');

module.exports = async function() {
    const { Requests, RequestHistory, Notifications } = this.entities;

    // Before CREATE - Set defaults and generate RequestID
    this.before('CREATE', 'Requests', async (req) => {
        const { data } = req;
        
        // Generate RequestID
        const count = await SELECT.one.from(Requests).columns('count(*) as count');
        const requestNumber = (count.count + 1).toString().padStart(6, '0');
        data.RequestID = `REQ-${new Date().getFullYear()}-${requestNumber}`;
        
        // Set requestor info from user context
        const user = req.user;
        data.RequestorNTID = user.id;
        data.RequestorFullName = user.attr.name;
        data.RequestorMailID = user.attr.email;
        
        // Set initial status
        data.StatusCode = 'DRAFT';
        
        // Determine approver based on project and table
        const approver = await this.getApproverForRequest(data.ProjectID, data.TableID);
        if (approver) {
            data.ApproverNTID = approver.approverNTID;
            data.ApproverFullName = approver.approverName;
        }
    });

    // After CREATE - Create history entry
    this.after('CREATE', 'Requests', async (data, req) => {
        await INSERT.into(RequestHistory).entries({
            request_ID: data.ID,
            action: 'CREATED',
            newStatus: 'DRAFT',
            performedBy: req.user.attr.name,
            performedByNTID: req.user.id,
            comments: 'Request created',
            timestamp: new Date()
        });
    });

    // Submit action
    this.on('submit', 'Requests', async (req) => {
        const { ID } = req.params[0];
        const request = await SELECT.one.from(Requests).where({ ID });
        
        if (!request) throw new Error('Request not found');
        if (request.StatusCode !== 'DRAFT') throw new Error('Only draft requests can be submitted');
        
        // Validate dates
        if (new Date(request.AccessFromDate) < new Date()) {
            throw new Error('Access from date cannot be in the past');
        }
        if (new Date(request.AccessEndDate) <= new Date(request.AccessFromDate)) {
            throw new Error('Access end date must be after from date');
        }
        
        // Update status
        await UPDATE(Requests).set({ StatusCode: 'SUBMITTED' }).where({ ID });
        
        // Create history entry
        await INSERT.into(RequestHistory).entries({
            request_ID: ID,
            action: 'SUBMITTED',
            oldStatus: 'DRAFT',
            newStatus: 'SUBMITTED',
            performedBy: req.user.attr.name,
            performedByNTID: req.user.id,
            comments: 'Request submitted for approval',
            timestamp: new Date()
        });
        
        // Send notification to approver
        await this.sendNotification(request.ApproverNTID, 'NEW_REQUEST', request);
        
        return SELECT.one.from(Requests).where({ ID });
    });

    // Cancel action
    this.on('cancel', 'Requests', async (req) => {
        const { ID } = req.params[0];
        const request = await SELECT.one.from(Requests).where({ ID });
        
        if (!request) throw new Error('Request not found');
        if (request.StatusCode !== 'DRAFT') throw new Error('Only draft requests can be cancelled');
        
        await UPDATE(Requests).set({ StatusCode: 'CANCELLED' }).where({ ID });
        
        await INSERT.into(RequestHistory).entries({
            request_ID: ID,
            action: 'CANCELLED',
            oldStatus: 'DRAFT',
            newStatus: 'CANCELLED',
            performedBy: req.user.attr.name,
            performedByNTID: req.user.id,
            comments: 'Request cancelled',
            timestamp: new Date()
        });
        
        return SELECT.one.from(Requests).where({ ID });
    });

    // Helper function to send notifications
    this.sendNotification = async function(recipientNTID, type, request) {
        // Implementation for sending email notifications
        // This would integrate with your email service
        console.log(`Notification sent to ${recipientNTID} for request ${request.RequestID}`);
    };

    // Restrict to own requests
    this.before(['READ', 'EDIT'], 'Requests', async (req) => {
        const user = req.user;
        req.query.where({ RequestorNTID: user.id });
    });
};
```

### 3.2 Approver Service Implementation

Create `srv/approver-service.js`:

```javascript
const cds = require('@sap/cds');

module.exports = async function() {
    const { Requests, RequestHistory, Notifications } = this.entities;

    // Approve action
    this.on('approve', 'Requests', async (req) => {
        const { ID } = req.params[0];
        const { comments } = req.data;
        const request = await SELECT.one.from(Requests).where({ ID });
        
        if (!request) throw new Error('Request not found');
        if (request.StatusCode !== 'SUBMITTED') {
            throw new Error('Only submitted requests can be approved');
        }
        
        // Update request
        await UPDATE(Requests).set({
            StatusCode: 'APPROVED',
            ApproverComments: comments,
            ApprovedDate: new Date()
        }).where({ ID });
        
        // Create history entry
        await INSERT.into(RequestHistory).entries({
            request_ID: ID,
            action: 'APPROVED',
            oldStatus: 'SUBMITTED',
            newStatus: 'APPROVED',
            performedBy: req.user.attr.name,
            performedByNTID: req.user.id,
            comments: comments || 'Request approved',
            timestamp: new Date()
        });
        
        // Send notification to requestor
        await this.sendNotification(request.RequestorNTID, 'REQUEST_APPROVED', request);
        
        return SELECT.one.from(Requests).where({ ID });
    });

    // Reject action
    this.on('reject', 'Requests', async (req) => {
        const { ID } = req.params[0];
        const { comments } = req.data;
        const request = await SELECT.one.from(Requests).where({ ID });
        
        if (!request) throw new Error('Request not found');
        if (request.StatusCode !== 'SUBMITTED') {
            throw new Error('Only submitted requests can be rejected');
        }
        
        if (!comments) {
            throw new Error('Comments are required for rejection');
        }
        
        await UPDATE(Requests).set({
            StatusCode: 'REJECTED',
            ApproverComments: comments,
            ApprovedDate: new Date()
        }).where({ ID });
        
        await INSERT.into(RequestHistory).entries({
            request_ID: ID,
            action: 'REJECTED',
            oldStatus: 'SUBMITTED',
            newStatus: 'REJECTED',
            performedBy: req.user.attr.name,
            performedByNTID: req.user.id,
            comments: comments,
            timestamp: new Date()
        });
        
        await this.sendNotification(request.RequestorNTID, 'REQUEST_REJECTED', request);
        
        return SELECT.one.from(Requests).where({ ID });
    });

    // Request more info action
    this.on('requestMoreInfo', 'Requests', async (req) => {
        const { ID } = req.params[0];
        const { comments } = req.data;
        const request = await SELECT.one.from(Requests).where({ ID });
        
        if (!request) throw new Error('Request not found');
        if (!comments) throw new Error('Comments are required');
        
        await UPDATE(Requests).set({
            StatusCode: 'MORE_INFO_REQUESTED',
            ApproverComments: comments
        }).where({ ID });
        
        await INSERT.into(RequestHistory).entries({
            request_ID: ID,
            action: 'MORE_INFO_REQUESTED',
            oldStatus: request.StatusCode,
            newStatus: 'MORE_INFO_REQUESTED',
            performedBy: req.user.attr.name,
            performedByNTID: req.user.id,
            comments: comments,
            timestamp: new Date()
        });
        
        await this.sendNotification(request.RequestorNTID, 'MORE_INFO_NEEDED', request);
        
        return SELECT.one.from(Requests).where({ ID });
    });

    // Get pending requests count
    this.on('getPendingRequestsCount', async (req) => {
        const user = req.user;
        const count = await SELECT.one.from(Requests)
            .columns('count(*) as count')
            .where({ ApproverNTID: user.id, StatusCode: 'SUBMITTED' });
        return count.count;
    });

    // Restrict to assigned requests
    this.before(['READ'], 'Requests', async (req) => {
        const user = req.user;
        req.query.where({ ApproverNTID: user.id });
    });
    
    this.sendNotification = async function(recipientNTID, type, request) {
        console.log(`Notification sent to ${recipientNTID} for request ${request.RequestID}`);
    };
};
```

---

## Step 4: Security Configuration

### 4.1 Create xs-security.json

```json
{
  "xsappname": "blulist-app",
  "tenant-mode": "dedicated",
  "scopes": [
    {
      "name": "$XSAPPNAME.Requestor",
      "description": "Requestor role"
    },
    {
      "name": "$XSAPPNAME.Approver",
      "description": "Approver role"
    },
    {
      "name": "$XSAPPNAME.Admin",
      "description": "Administrator role"
    }
  ],
  "role-templates": [
    {
      "name": "Requestor",
      "description": "Can create and view own requests",
      "scope-references": [
        "$XSAPPNAME.Requestor"
      ]
    },
    {
      "name": "Approver",
      "description": "Can approve/reject requests",
      "scope-references": [
        "$XSAPPNAME.Approver"
      ]
    },
    {
      "name": "Admin",
      "description": "Full access to system",
      "scope-references": [
        "$XSAPPNAME.Admin"
      ]
    }
  ],
  "role-collections": [
    {
      "name": "BlulistRequestor",
      "description": "Blulist Requestor Role Collection",
      "role-template-references": [
        "$XSAPPNAME.Requestor"
      ]
    },
    {
      "name": "BlulistApprover",
      "description": "Blulist Approver Role Collection",
      "role-template-references": [
        "$XSAPPNAME.Approver"
      ]
    },
    {
      "name": "BlulistAdmin",
      "description": "Blulist Administrator Role Collection",
      "role-template-references": [
        "$XSAPPNAME.Admin"
      ]
    }
  ]
}
```

---

## Step 5: Local Development Setup

### 5.1 Configure Local Development

Update `.cdsrc.json`:

```json
{
  "requires": {
    "db": {
      "kind": "sqlite",
      "[production]": {
        "kind": "hana"
      }
    },
    "auth": {
      "kind": "dummy",
      "[production]": {
        "kind": "xsuaa"
      }
    }
  }
}
```

### 5.2 Deploy Database Locally

```bash
cds deploy --to sqlite
```

### 5.3 Start Development Server

```bash
cds watch
```

Access the application at `http://localhost:4004`

---

## Step 6: Testing

### 6.1 Create Test Files

Create `test/requestor-service.test.js`:

```javascript
const cds = require('@sap/cds');
const { GET, POST, expect } = cds.test(__dirname + '/..');

describe('Requestor Service Tests', () => {
    it('Should create a new request', async () => {
        const response = await POST('/requestor/Requests', {
            ProjectID: 'PRJ001',
            TableID: 'TBL001',
            RoleCode: 'FIORI_DEV',
            AccessFromDate: '2026-03-01',
            AccessEndDate: '2026-06-01',
            ReqComments: 'Test request'
        });
        expect(response.status).to.equal(201);
    });

    it('Should list requestor requests', async () => {
        const response = await GET('/requestor/Requests');
        expect(response.status).to.equal(200);
    });
});
```

### 6.2 Run Tests

```bash
npm test
```

---

## Step 7: SAP BTP Deployment

### 7.1 Create mta.yaml

```yaml
_schema-version: '3.2'
ID: blulist-app
version: 1.0.0
description: Project Role Request Management System

modules:
  - name: blulist-app-srv
    type: nodejs
    path: gen/srv
    requires:
      - name: blulist-app-db
      - name: blulist-app-uaa
    provides:
      - name: srv-api
        properties:
          srv-url: ${default-url}

  - name: blulist-app-db-deployer
    type: hdb
    path: gen/db
    requires:
      - name: blulist-app-db

resources:
  - name: blulist-app-db
    type: com.sap.xs.hdi-container
    properties:
      hdi-container-name: ${service-name}

  - name: blulist-app-uaa
    type: org.cloudfoundry.managed-service
    parameters:
      service: xsuaa
      service-plan: application
      path: ./xs-security.json
```

### 7.2 Build MTA

```bash
mbt build
```

### 7.3 Deploy to Cloud Foundry

```bash
cf login -a <api-endpoint>
cf deploy mta_archives/blulist-app_1.0.0.mtar
```

---

## Step 8: Post-Deployment Configuration

### 8.1 Assign Role Collections

1. Go to SAP BTP Cockpit
2. Navigate to Security → Role Collections
3. Assign role collections to users:
   - `BlulistRequestor`
   - `BlulistApprover`
   - `BlulistAdmin`

### 8.2 Configure Destinations (if needed)

Create destinations for external systems integration.

---

## Step 9: Monitoring and Operations

### 9.1 Application Logs

```bash
cf logs blulist-app-srv --recent
```

### 9.2 Database Access

```bash
# Bind to HDI container
cf bind-service blulist-app-srv blulist-app-db

# Create service key
cf create-service-key blulist-app-db blulist-app-db-key

# Get credentials
cf service-key blulist-app-db blulist-app-db-key
```

---

## Common Issues and Troubleshooting

### Issue 1: Authentication Errors
**Solution**: Verify xs-security.json and role assignments

### Issue 2: Database Connection Errors
**Solution**: Check HDI container binding and credentials

### Issue 3: Service Not Starting
**Solution**: Review application logs for detailed error messages

### Issue 4: Authorization Failures
**Solution**: Ensure user has correct role collection assigned

---

## Next Steps

1. **Develop Fiori UI Applications**
   - Create Fiori Elements apps for Requestor, Approver, and Admin
   - Configure Fiori Launchpad

2. **Implement Email Notifications**
   - Integrate with SAP Cloud Platform Email Service
   - Create email templates

3. **Add Advanced Features**
   - Workflow integration
   - Analytics dashboard
   - Mobile app support

4. **Performance Optimization**
   - Add indexes on frequently queried fields
   - Implement caching where appropriate
   - Optimize OData queries

5. **Security Hardening**
   - Implement input validation
   - Add rate limiting
   - Enable audit logging

---

## Resources

- [SAP CAP Documentation](https://cap.cloud.sap/docs/)
- [SAP Fiori Elements](https://ui5.sap.com/test-resources/sap/fe/core/fpmExplorer/index.html)
- [SAP BTP Documentation](https://help.sap.com/docs/BTP)
- [Cloud Foundry CLI](https://docs.cloudfoundry.org/cf-cli/)

---

## Support

For issues or questions, please contact:
- Email: support@company.com
- Internal Help Desk: Ticket System
