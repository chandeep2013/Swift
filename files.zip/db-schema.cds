namespace com.blulist.app;

using {
    cuid,
    managed,
    sap.common.CodeList
} from '@sap/cds/common';

/**
 * Requestor Entity - Stores requestor information
 */
entity Requestors : cuid, managed {
    NTID                : String(20) @title: 'Network ID';
    FullName            : String(100) @title: 'Full Name';
    EmailID             : String(100) @title: 'Email Address';
    requests            : Association to many Requests
                              on requests.requestor = $self;
}

/**
 * Approver Entity - Stores approver information
 */
entity Approvers : cuid, managed {
    NTID                : String(20) @title: 'Network ID';
    FullName            : String(100) @title: 'Full Name';
    EmailID             : String(100) @title: 'Email Address';
    project             : Association to Projects @title: 'Project';
    table               : Association to Tables @title: 'Table';
    approvedRequests    : Association to many Requests
                              on approvedRequests.approver = $self;
}

/**
 * Projects Entity - Master data for projects
 */
entity Projects : cuid, managed {
    ProjectID           : String(20) @title: 'Project ID';
    ProjectName         : String(100) @title: 'Project Name';
    requests            : Association to many Requests
                              on requests.project = $self;
    tables              : Association to many Tables
                              on tables.project = $self;
    approvers           : Association to many Approvers
                              on approvers.project = $self;
}

/**
 * Tables Entity - Master data for tables/modules
 */
entity Tables : cuid, managed {
    TableID             : String(20) @title: 'Table ID';
    TableName           : String(100) @title: 'Table Name';
    TableOwner          : String(100) @title: 'Table Owner';
    TableOwnerMailID    : String(100) @title: 'Table Owner Email';
    project             : Association to Projects @title: 'Project';
    requests            : Association to many Requests
                              on requests.table = $self;
    approvers           : Association to many Approvers
                              on approvers.table = $self;
}

/**
 * Roles Entity - Master data for project roles
 */
entity Roles : CodeList {
    key code            : String(50) @title: 'Role Code';
        name            : String(100) @title: 'Role Name';
        description     : String(500) @title: 'Role Description';
        isActive        : Boolean default true @title: 'Active Status';
        requests        : Association to many Requests
                              on requests.role = $self;
}

/**
 * Request Status Code List
 */
entity RequestStatus : CodeList {
    key code            : String(20) @title: 'Status Code';
        name            : String(50) @title: 'Status Name';
        description     : String(200) @title: 'Status Description';
}

/**
 * Main Requests Entity - Core entity for access requests
 */
entity Requests : cuid, managed {
    RequestID           : String(20) @title: 'Request ID' @readonly;
    
    // Requestor Information
    requestor           : Association to Requestors @title: 'Requestor';
    RequestorNTID       : String(20) @title: 'Requestor NTID';
    RequestorFullName   : String(100) @title: 'Requestor Name';
    RequestorMailID     : String(100) @title: 'Requestor Email';
    
    // Request Details
    project             : Association to Projects @title: 'Project';
    ProjectID           : String(20) @title: 'Project ID';
    
    table               : Association to Tables @title: 'Table/Module';
    TableID             : String(20) @title: 'Table ID';
    
    role                : Association to Roles @title: 'Requested Role';
    RoleCode            : String(50) @title: 'Role Code';
    
    // Access Period
    AccessFromDate      : Date @title: 'Access From Date';
    AccessEndDate       : Date @title: 'Access End Date';
    
    // Comments
    ReqComments         : String(1000) @title: 'Requestor Comments';
    ApproverComments    : String(1000) @title: 'Approver Comments';
    
    // Approver Information
    approver            : Association to Approvers @title: 'Approver';
    ApproverNTID        : String(20) @title: 'Approver NTID';
    ApproverFullName    : String(100) @title: 'Approver Name';
    
    // Status
    status              : Association to RequestStatus @title: 'Request Status';
    StatusCode          : String(20) @title: 'Status Code' default 'SUBMITTED';
    
    // Approval Date
    ApprovedDate        : DateTime @title: 'Approval/Rejection Date';
    
    // Audit Trail
    history             : Composition of many RequestHistory
                              on history.request = $self;
}

/**
 * Request History Entity - Audit trail for requests
 */
entity RequestHistory : cuid, managed {
    request             : Association to Requests @title: 'Request';
    action              : String(50) @title: 'Action';
    oldStatus           : String(20) @title: 'Old Status';
    newStatus           : String(20) @title: 'New Status';
    performedBy         : String(100) @title: 'Performed By';
    performedByNTID     : String(20) @title: 'Performed By NTID';
    comments            : String(1000) @title: 'Comments';
    timestamp           : DateTime @title: 'Timestamp';
}

/**
 * Request Attachments Entity - For supporting documents
 */
entity RequestAttachments : cuid, managed {
    request             : Association to Requests @title: 'Request';
    fileName            : String(200) @title: 'File Name';
    fileType            : String(50) @title: 'File Type';
    fileSize            : Integer @title: 'File Size (KB)';
    fileContent         : LargeBinary @title: 'File Content';
    uploadedBy          : String(100) @title: 'Uploaded By';
    uploadedDate        : DateTime @title: 'Upload Date';
}

/**
 * Notifications Entity - For email/notification tracking
 */
entity Notifications : cuid, managed {
    request             : Association to Requests @title: 'Request';
    recipient           : String(100) @title: 'Recipient Email';
    recipientNTID       : String(20) @title: 'Recipient NTID';
    subject             : String(200) @title: 'Subject';
    body                : String(2000) @title: 'Body';
    notificationType    : String(50) @title: 'Notification Type'; // EMAIL, IN_APP, SMS
    sentDate            : DateTime @title: 'Sent Date';
    status              : String(20) @title: 'Status'; // SENT, FAILED, PENDING
    failureReason       : String(500) @title: 'Failure Reason';
}

/**
 * User Preferences Entity - Store user-specific settings
 */
entity UserPreferences : cuid, managed {
    NTID                : String(20) @title: 'Network ID';
    emailNotifications  : Boolean default true @title: 'Email Notifications';
    inAppNotifications  : Boolean default true @title: 'In-App Notifications';
    language            : String(10) default 'EN' @title: 'Language';
    theme               : String(20) default 'SAP_HORIZON' @title: 'Theme';
}

/**
 * Dashboard Metrics Entity - For analytics and reporting
 */
entity DashboardMetrics : cuid {
    metricDate          : Date @title: 'Metric Date';
    totalRequests       : Integer @title: 'Total Requests';
    pendingRequests     : Integer @title: 'Pending Requests';
    approvedRequests    : Integer @title: 'Approved Requests';
    rejectedRequests    : Integer @title: 'Rejected Requests';
    avgApprovalTime     : Decimal(10, 2) @title: 'Avg Approval Time (hours)';
    projectID           : String(20) @title: 'Project ID';
}
