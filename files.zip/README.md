# Blulist - SAP CAP Project Role Request Management System

A comprehensive SAP Cloud Application Programming Model (CAP) based application for managing project role access requests with approval workflows.

## 📋 Overview

The Blulist application enables organizations to streamline the process of requesting and approving access to project roles. It provides separate interfaces for requestors, approvers, and administrators, with complete audit trails and notification capabilities.

## ✨ Key Features

- **Request Management**: Create, track, and manage access requests for project roles
- **Approval Workflow**: Review, approve, reject, or delegate requests with comments
- **Master Data Management**: Manage projects, tables, roles, and user information
- **Audit Trail**: Complete history tracking for all request actions
- **Notifications**: Email and in-app notifications for key events
- **Role-Based Access Control**: Separate interfaces for Requestors, Approvers, and Admins
- **Real-time Dashboard**: Analytics and insights for administrators
- **Multi-level Security**: Built on SAP BTP with XSUAA authentication

## 🏗️ Architecture

### Technology Stack

- **Backend**: SAP CAP (Node.js)
- **Database**: SAP HANA Cloud / SQLite (for development)
- **Frontend**: SAP Fiori Elements / SAPUI5
- **Protocol**: OData V4
- **Security**: SAP XSUAA
- **Platform**: SAP Business Technology Platform (Cloud Foundry)

### Core Components

1. **Database Layer**: 10+ entities including Requests, Requestors, Approvers, Projects, Tables, Roles
2. **Service Layer**: 4 OData services (Requestor, Approver, Admin, Common)
3. **Business Logic**: Custom handlers for workflow management
4. **UI Layer**: Fiori applications for each user role
5. **Integration Layer**: Email notifications and external system connectors

## 📂 Project Structure

```
blulist-app/
├── db/
│   ├── schema.cds              # Database schema definition
│   ├── data/                   # Sample data
│   └── sample-data.sql         # Initial data load script
├── srv/
│   ├── service-definition.cds  # Service definitions
│   ├── requestor-service.js    # Requestor service implementation
│   ├── approver-service.js     # Approver service implementation
│   ├── admin-service.js        # Admin service implementation
│   └── common-service.js       # Common utilities
├── app/
│   ├── requestor/             # Requestor Fiori app
│   ├── approver/              # Approver Fiori app
│   └── admin/                 # Admin console
├── test/                      # Test cases
├── docs/
│   ├── ARCHITECTURE.md        # Detailed architecture documentation
│   └── IMPLEMENTATION_GUIDE.md # Step-by-step implementation guide
├── xs-security.json           # Security configuration
├── mta.yaml                   # Multi-target application descriptor
└── package.json               # Project dependencies
```

## 📊 Database Schema

### Main Entities

1. **Requestors**: Users who create access requests
2. **Approvers**: Users who review and approve/reject requests
3. **Projects**: Project master data
4. **Tables**: Tables/modules within projects
5. **Roles**: Available project roles (Fiori Developer, ABAP Developer, etc.)
6. **Requests**: Core entity storing access requests with full lifecycle
7. **RequestHistory**: Audit trail for all request actions
8. **RequestStatus**: Status code list (Draft, Submitted, Approved, Rejected, etc.)
9. **Notifications**: Email and notification tracking
10. **RequestAttachments**: Supporting documents for requests

## 🔄 Request Lifecycle

```
DRAFT → SUBMITTED → APPROVED/REJECTED
                ↓
        MORE_INFO_REQUESTED → DRAFT
        
Additional States: CANCELLED, WITHDRAWN, EXPIRED
```

## 🚀 Getting Started

### Prerequisites

- Node.js v18 or higher
- SAP CAP CLI (`npm install -g @sap/cds-dk`)
- SAP BTP account (for deployment)
- Git

### Local Development Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd blulist-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Deploy database locally**
   ```bash
   cds deploy --to sqlite
   ```

4. **Start development server**
   ```bash
   cds watch
   ```

5. **Access the application**
   - URL: http://localhost:4004
   - API: http://localhost:4004/requestor, /approver, /admin

### Running Tests

```bash
npm test
```

## 🔐 Security & Authorization

### User Roles

| Role | Permissions |
|------|------------|
| **Requestor** | Create requests, view own requests, submit/cancel, upload attachments |
| **Approver** | View assigned requests, approve/reject, delegate, add comments |
| **Admin** | Full CRUD on all entities, analytics, system configuration, user management |

### Authentication Flow

1. User authenticates via SAP XSUAA
2. JWT token issued with user claims
3. Role-based access control enforced at service level
4. Data ownership restrictions applied (e.g., requestor sees only own requests)

## 📱 User Interfaces

### Requestor App
- Create new access requests
- Track request status
- View request history
- Upload supporting documents
- Manage preferences

### Approver App
- Pending requests dashboard
- Detailed request review
- Approve/reject with comments
- Request more information
- Delegate to other approvers

### Admin Console
- Master data management
- View all requests
- Analytics and reporting
- System configuration
- Bulk operations

## 🔗 API Endpoints

### Requestor Service (`/requestor`)
- `GET /Requests` - View own requests
- `POST /Requests` - Create new request
- `POST /Requests(ID)/submit` - Submit request for approval
- `POST /Requests(ID)/cancel` - Cancel draft request

### Approver Service (`/approver`)
- `GET /Requests` - View assigned requests
- `POST /Requests(ID)/approve` - Approve request
- `POST /Requests(ID)/reject` - Reject request
- `POST /Requests(ID)/requestMoreInfo` - Request more information

### Admin Service (`/admin`)
- Full CRUD operations on all entities
- Analytics functions
- Bulk operations
- Reporting endpoints

## 📈 Analytics & Reporting

The Admin Dashboard provides:
- Total requests by status
- Average approval time
- Top requested roles
- Requests by project
- Approver performance metrics
- Trend analysis

## 🔔 Notifications

### Notification Types

- **Request Submitted**: Sent to approver when new request is submitted
- **Request Approved**: Sent to requestor when request is approved
- **Request Rejected**: Sent to requestor when request is rejected
- **More Info Needed**: Sent to requestor when approver needs clarification
- **Request Delegated**: Sent to new approver when request is reassigned
- **Reminder**: Sent to approver for pending requests

## 🚢 Deployment

### Build for Production

```bash
mbt build
```

### Deploy to Cloud Foundry

```bash
cf login -a <api-endpoint>
cf deploy mta_archives/blulist-app_1.0.0.mtar
```

### Post-Deployment

1. Assign role collections to users in BTP Cockpit
2. Configure email service
3. Set up monitoring and logging
4. Configure destinations (if needed)

## 📖 Documentation

- [ARCHITECTURE.md](./ARCHITECTURE.md) - Detailed architecture and design decisions
- [IMPLEMENTATION_GUIDE.md](./IMPLEMENTATION_GUIDE.md) - Step-by-step implementation instructions
- [API Documentation](./docs/API.md) - Complete API reference (generated from OData)

## 🧪 Testing

The project includes:
- Unit tests for service handlers
- Integration tests for API endpoints
- Data validation tests
- Authorization tests

## 🛠️ Configuration

### Environment Variables

- `NODE_ENV`: Environment (development, production)
- `VCAP_SERVICES`: Cloud Foundry services binding
- `PORT`: Application port (default: 4004)

### Feature Flags

Configure optional features in `.cdsrc.json`:
- Email notifications
- Audit logging level
- Multi-tenancy support
- External integrations

## 🔄 Future Enhancements

1. **Workflow Engine**: BPM integration for complex approval chains
2. **Mobile App**: Native iOS/Android applications
3. **AI/ML**: Predict approval likelihood, recommend approvers
4. **Advanced Analytics**: Predictive insights and forecasting
5. **Multi-level Approval**: Escalation and multi-tier approval flows
6. **Auto-provisioning**: Automatic access provisioning upon approval
7. **Compliance**: SOX and audit compliance reports
8. **Chatbot**: Request creation via conversational AI

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the ISC License.

## 👥 Team

- **Project Owner**: [Your Name]
- **Lead Developer**: [Developer Name]
- **Architect**: [Architect Name]

## 📧 Support

For questions or issues:
- Email: support@company.com
- Help Desk: [Ticket System URL]
- Documentation: [Wiki URL]

## 🙏 Acknowledgments

- SAP CAP Framework team
- SAP Fiori Design Guidelines
- Open source community

---

**Built with ❤️ using SAP Cloud Application Programming Model**
