// Sample data for RequestStatus
INSERT INTO com_blulist_app_RequestStatus (code, name, description) VALUES ('DRAFT', 'Draft', 'Request is in draft state');
INSERT INTO com_blulist_app_RequestStatus (code, name, description) VALUES ('SUBMITTED', 'Submitted', 'Request has been submitted for approval');
INSERT INTO com_blulist_app_RequestStatus (code, name, description) VALUES ('APPROVED', 'Approved', 'Request has been approved');
INSERT INTO com_blulist_app_RequestStatus (code, name, description) VALUES ('REJECTED', 'Rejected', 'Request has been rejected');
INSERT INTO com_blulist_app_RequestStatus (code, name, description) VALUES ('MORE_INFO_REQUESTED', 'More Info Requested', 'Additional information requested by approver');
INSERT INTO com_blulist_app_RequestStatus (code, name, description) VALUES ('CANCELLED', 'Cancelled', 'Request cancelled by requestor');
INSERT INTO com_blulist_app_RequestStatus (code, name, description) VALUES ('WITHDRAWN', 'Withdrawn', 'Request withdrawn after submission');
INSERT INTO com_blulist_app_RequestStatus (code, name, description) VALUES ('EXPIRED', 'Expired', 'Request access period has expired');

// Sample data for Roles
INSERT INTO com_blulist_app_Roles (code, name, description, isActive) VALUES ('FIORI_DEV', 'Fiori Developer', 'Developer with Fiori development access', true);
INSERT INTO com_blulist_app_Roles (code, name, description, isActive) VALUES ('FIORI_CONFIG', 'Fiori Configurator', 'Configurator for Fiori applications', true);
INSERT INTO com_blulist_app_Roles (code, name, description, isActive) VALUES ('LEAD_DEV', 'Lead Developer', 'Lead developer role with extended access', true);
INSERT INTO com_blulist_app_Roles (code, name, description, isActive) VALUES ('TDM', 'TDM', 'Test Data Manager role', true);
INSERT INTO com_blulist_app_Roles (code, name, description, isActive) VALUES ('ABAP_DEV', 'ABAP Developer', 'ABAP development access', true);
INSERT INTO com_blulist_app_Roles (code, name, description, isActive) VALUES ('AUTH_DEV', 'Authorization Developer', 'Authorization development and configuration', true);
INSERT INTO com_blulist_app_Roles (code, name, description, isActive) VALUES ('SUPPORT_ACCESS', 'Support Access', 'Read-only support access', true);

// Sample data for Projects
INSERT INTO com_blulist_app_Projects (ID, ProjectID, ProjectName, createdAt) VALUES ('P001', 'PRJ001', 'SAP S/4HANA Implementation', NOW());
INSERT INTO com_blulist_app_Projects (ID, ProjectID, ProjectName, createdAt) VALUES ('P002', 'PRJ002', 'Fiori Launchpad Rollout', NOW());
INSERT INTO com_blulist_app_Projects (ID, ProjectID, ProjectName, createdAt) VALUES ('P003', 'PRJ003', 'BTP Cloud Migration', NOW());
INSERT INTO com_blulist_app_Projects (ID, ProjectID, ProjectName, createdAt) VALUES ('P004', 'PRJ004', 'Integration Hub Project', NOW());

// Sample data for Tables
INSERT INTO com_blulist_app_Tables (ID, TableID, TableName, TableOwner, TableOwnerMailID, project_ID, createdAt) 
VALUES ('T001', 'TBL001', 'Material Master', 'John Smith', 'john.smith@company.com', 'P001', NOW());

INSERT INTO com_blulist_app_Tables (ID, TableID, TableName, TableOwner, TableOwnerMailID, project_ID, createdAt) 
VALUES ('T002', 'TBL002', 'Sales Orders', 'Jane Doe', 'jane.doe@company.com', 'P001', NOW());

INSERT INTO com_blulist_app_Tables (ID, TableID, TableName, TableOwner, TableOwnerMailID, project_ID, createdAt) 
VALUES ('T003', 'TBL003', 'Purchase Orders', 'Mike Johnson', 'mike.johnson@company.com', 'P001', NOW());

INSERT INTO com_blulist_app_Tables (ID, TableID, TableName, TableOwner, TableOwnerMailID, project_ID, createdAt) 
VALUES ('T004', 'TBL004', 'Inventory Management', 'Sarah Wilson', 'sarah.wilson@company.com', 'P002', NOW());

INSERT INTO com_blulist_app_Tables (ID, TableID, TableName, TableOwner, TableOwnerMailID, project_ID, createdAt) 
VALUES ('T005', 'TBL005', 'Financial Accounting', 'Robert Brown', 'robert.brown@company.com', 'P003', NOW());

// Sample data for Requestors
INSERT INTO com_blulist_app_Requestors (ID, NTID, FullName, EmailID, createdAt) 
VALUES ('R001', 'JDOE001', 'John Doe', 'john.doe@company.com', NOW());

INSERT INTO com_blulist_app_Requestors (ID, NTID, FullName, EmailID, createdAt) 
VALUES ('R002', 'ASMITH002', 'Alice Smith', 'alice.smith@company.com', NOW());

INSERT INTO com_blulist_app_Requestors (ID, NTID, FullName, EmailID, createdAt) 
VALUES ('R003', 'BWILSON003', 'Bob Wilson', 'bob.wilson@company.com', NOW());

// Sample data for Approvers
INSERT INTO com_blulist_app_Approvers (ID, NTID, FullName, EmailID, project_ID, table_ID, createdAt) 
VALUES ('A001', 'MJONES001', 'Manager Jones', 'manager.jones@company.com', 'P001', 'T001', NOW());

INSERT INTO com_blulist_app_Approvers (ID, NTID, FullName, EmailID, project_ID, table_ID, createdAt) 
VALUES ('A002', 'LDAVIS002', 'Lead Davis', 'lead.davis@company.com', 'P001', 'T002', NOW());

INSERT INTO com_blulist_app_Approvers (ID, NTID, FullName, EmailID, project_ID, table_ID, createdAt) 
VALUES ('A003', 'SMILLER003', 'Supervisor Miller', 'supervisor.miller@company.com', 'P002', 'T004', NOW());

// Sample data for Requests
INSERT INTO com_blulist_app_Requests (
    ID, RequestID, requestor_ID, RequestorNTID, RequestorFullName, RequestorMailID,
    project_ID, ProjectID, table_ID, TableID, role_code, RoleCode,
    AccessFromDate, AccessEndDate, ReqComments, 
    approver_ID, ApproverNTID, ApproverFullName,
    status_code, StatusCode, createdAt
) VALUES (
    'REQ001', 'REQ-2026-001', 'R001', 'JDOE001', 'John Doe', 'john.doe@company.com',
    'P001', 'PRJ001', 'T001', 'TBL001', 'FIORI_DEV', 'FIORI_DEV',
    '2026-02-16', '2026-05-16', 'Need access for Q1 development work',
    'A001', 'MJONES001', 'Manager Jones',
    'SUBMITTED', 'SUBMITTED', NOW()
);

INSERT INTO com_blulist_app_Requests (
    ID, RequestID, requestor_ID, RequestorNTID, RequestorFullName, RequestorMailID,
    project_ID, ProjectID, table_ID, TableID, role_code, RoleCode,
    AccessFromDate, AccessEndDate, ReqComments,
    approver_ID, ApproverNTID, ApproverFullName,
    status_code, StatusCode, ApprovedDate, ApproverComments, createdAt
) VALUES (
    'REQ002', 'REQ-2026-002', 'R002', 'ASMITH002', 'Alice Smith', 'alice.smith@company.com',
    'P001', 'PRJ001', 'T002', 'TBL002', 'ABAP_DEV', 'ABAP_DEV',
    '2026-02-10', '2026-04-10', 'Required for enhancement development',
    'A002', 'LDAVIS002', 'Lead Davis',
    'APPROVED', 'APPROVED', NOW(), 'Approved for 2 months', NOW()
);

INSERT INTO com_blulist_app_Requests (
    ID, RequestID, requestor_ID, RequestorNTID, RequestorFullName, RequestorMailID,
    project_ID, ProjectID, table_ID, TableID, role_code, RoleCode,
    AccessFromDate, AccessEndDate, ReqComments,
    status_code, StatusCode, createdAt
) VALUES (
    'REQ003', 'REQ-2026-003', 'R003', 'BWILSON003', 'Bob Wilson', 'bob.wilson@company.com',
    'P002', 'PRJ002', 'T004', 'TBL004', 'FIORI_CONFIG', 'FIORI_CONFIG',
    '2026-02-20', '2026-06-20', 'Configuration access needed for Fiori apps',
    'DRAFT', 'DRAFT', NOW()
);

// Sample data for RequestHistory
INSERT INTO com_blulist_app_RequestHistory (
    ID, request_ID, action, oldStatus, newStatus, 
    performedBy, performedByNTID, comments, timestamp, createdAt
) VALUES (
    'H001', 'REQ001', 'CREATED', null, 'DRAFT', 
    'John Doe', 'JDOE001', 'Request created', NOW(), NOW()
);

INSERT INTO com_blulist_app_RequestHistory (
    ID, request_ID, action, oldStatus, newStatus, 
    performedBy, performedByNTID, comments, timestamp, createdAt
) VALUES (
    'H002', 'REQ001', 'SUBMITTED', 'DRAFT', 'SUBMITTED', 
    'John Doe', 'JDOE001', 'Request submitted for approval', NOW(), NOW()
);

INSERT INTO com_blulist_app_RequestHistory (
    ID, request_ID, action, oldStatus, newStatus, 
    performedBy, performedByNTID, comments, timestamp, createdAt
) VALUES (
    'H003', 'REQ002', 'CREATED', null, 'DRAFT', 
    'Alice Smith', 'ASMITH002', 'Request created', NOW(), NOW()
);

INSERT INTO com_blulist_app_RequestHistory (
    ID, request_ID, action, oldStatus, newStatus, 
    performedBy, performedByNTID, comments, timestamp, createdAt
) VALUES (
    'H004', 'REQ002', 'SUBMITTED', 'DRAFT', 'SUBMITTED', 
    'Alice Smith', 'ASMITH002', 'Request submitted for approval', NOW(), NOW()
);

INSERT INTO com_blulist_app_RequestHistory (
    ID, request_ID, action, oldStatus, newStatus, 
    performedBy, performedByNTID, comments, timestamp, createdAt
) VALUES (
    'H005', 'REQ002', 'APPROVED', 'SUBMITTED', 'APPROVED', 
    'Lead Davis', 'LDAVIS002', 'Approved for 2 months', NOW(), NOW()
);
