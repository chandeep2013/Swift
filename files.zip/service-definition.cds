using {com.blulist.app as db} from '../db/schema';

/**
 * Requestor Service - For requestors to create and manage their requests
 */
service RequestorService @(path: '/requestor') {

    // Requestor can view their own profile
    entity Requestors as projection on db.Requestors
        excluding {
            createdBy,
            modifiedBy
        };

    // Requestor can create and view their own requests
    entity Requests as projection on db.Requests
        excluding {
            createdBy,
            modifiedBy
        } actions {
            action submit() returns Requests;
            action cancel() returns Requests;
            action withdraw() returns Requests;
        };

    // Read-only access to master data
    @readonly
    entity Projects as projection on db.Projects;

    @readonly
    entity Tables as projection on db.Tables;

    @readonly
    entity Roles as projection on db.Roles;

    @readonly
    entity RequestStatus as projection on db.RequestStatus;

    // View request history
    @readonly
    entity RequestHistory as projection on db.RequestHistory;

    // Manage attachments
    entity RequestAttachments as projection on db.RequestAttachments;

    // View notifications
    @readonly
    entity Notifications as projection on db.Notifications;

    // Manage user preferences
    entity UserPreferences as projection on db.UserPreferences;

    // Function to get approver for a project/table combination
    function getApproverForRequest(projectID: String, tableID: String) returns {
        approverNTID: String;
        approverName: String;
        approverEmail: String;
    };

    // Function to validate access dates
    function validateAccessDates(fromDate: Date, endDate: Date) returns {
        isValid: Boolean;
        message: String;
    };
}

/**
 * Approver Service - For approvers to review and approve/reject requests
 */
service ApproverService @(path: '/approver') {

    // Approver can view their profile
    entity Approvers as projection on db.Approvers
        excluding {
            createdBy,
            modifiedBy
        };

    // Approver can view and action on requests
    entity Requests as projection on db.Requests
        excluding {
            createdBy,
            modifiedBy
        } actions {
            action approve(comments: String) returns Requests;
            action reject(comments: String) returns Requests;
            action requestMoreInfo(comments: String) returns Requests;
            action delegate(newApproverNTID: String, comments: String) returns Requests;
        };

    // Read-only access to related entities
    @readonly
    entity Requestors as projection on db.Requestors;

    @readonly
    entity Projects as projection on db.Projects;

    @readonly
    entity Tables as projection on db.Tables;

    @readonly
    entity Roles as projection on db.Roles;

    @readonly
    entity RequestStatus as projection on db.RequestStatus;

    @readonly
    entity RequestHistory as projection on db.RequestHistory;

    @readonly
    entity RequestAttachments as projection on db.RequestAttachments;

    // View notifications
    @readonly
    entity Notifications as projection on db.Notifications;

    // Function to get pending requests count
    function getPendingRequestsCount() returns Integer;

    // Function to get requests by status
    function getRequestsByStatus(status: String) returns array of Requests;

    // Function to get overdue requests
    function getOverdueRequests() returns array of Requests;
}

/**
 * Admin Service - For administrators to manage master data and view analytics
 */
service AdminService @(path: '/admin') {

    // Full access to master data
    entity Requestors as projection on db.Requestors;
    entity Approvers as projection on db.Approvers;
    entity Projects as projection on db.Projects;
    entity Tables as projection on db.Tables;
    entity Roles as projection on db.Roles;
    entity RequestStatus as projection on db.RequestStatus;

    // View all requests
    entity Requests as projection on db.Requests actions {
        action reassign(newApproverNTID: String) returns Requests;
        action bulkApprove(requestIDs: array of String) returns String;
        action bulkReject(requestIDs: array of String) returns String;
    };

    // Audit trail
    @readonly
    entity RequestHistory as projection on db.RequestHistory;

    // Attachments
    @readonly
    entity RequestAttachments as projection on db.RequestAttachments;

    // Notifications
    entity Notifications as projection on db.Notifications;

    // User Preferences
    entity UserPreferences as projection on db.UserPreferences;

    // Dashboard Metrics
    entity DashboardMetrics as projection on db.DashboardMetrics;

    // Analytics functions
    function getRequestStatistics(fromDate: Date, toDate: Date) returns {
        totalRequests: Integer;
        approved: Integer;
        rejected: Integer;
        pending: Integer;
        avgApprovalTime: Decimal;
    };

    function getTopRequestedRoles(limit: Integer) returns array of {
        roleCode: String;
        roleName: String;
        count: Integer;
    };

    function getRequestsByProject() returns array of {
        projectID: String;
        projectName: String;
        totalRequests: Integer;
        pendingRequests: Integer;
    };

    function getApproverPerformance() returns array of {
        approverNTID: String;
        approverName: String;
        totalApproved: Integer;
        totalRejected: Integer;
        avgResponseTime: Decimal;
    };

    // Bulk operations
    action sendReminderNotifications(requestIDs: array of String) returns String;
    action exportRequests(filterCriteria: String) returns LargeBinary;
}

/**
 * Common Service - Public endpoints for lookups
 */
service CommonService @(path: '/common') {

    @readonly
    entity Projects as projection on db.Projects;

    @readonly
    entity Tables as projection on db.Tables;

    @readonly
    entity Roles as projection on db.Roles;

    @readonly
    entity RequestStatus as projection on db.RequestStatus;

    // Function to get approvers by project
    function getApproversByProject(projectID: String) returns array of {
        approverNTID: String;
        approverName: String;
        approverEmail: String;
    };

    // Function to validate user
    function validateUser(ntid: String) returns {
        isValid: Boolean;
        userType: String; // REQUESTOR, APPROVER, ADMIN
        fullName: String;
        email: String;
    };
}

/**
 * Annotation for authorization
 */
annotate RequestorService with @(requires: 'Requestor');
annotate ApproverService with @(requires: 'Approver');
annotate AdminService with @(requires: 'Admin');
annotate CommonService with @(requires: 'authenticated-user');
